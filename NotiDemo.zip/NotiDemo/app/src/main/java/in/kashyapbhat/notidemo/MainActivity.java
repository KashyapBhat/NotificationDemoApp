package in.kashyapbhat.notidemo;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    AlarmManager alarmManager;
    Button start,stop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start =findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Alarm Created", Toast.LENGTH_SHORT).show();
                Intent it= new Intent();
                it.setAction("com.my.example.receiver.message");
                it.addCategory("android.intent.category.DEFAULT");
                PendingIntent pd =PendingIntent.getActivity(MainActivity.this,1,it,PendingIntent.FLAG_UPDATE_CURRENT);
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(),1000*10,pd);

            }
        });
        stop =findViewById(R.id.stop);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Alarm Stopped", Toast.LENGTH_SHORT).show();
                Intent it= new Intent();
                it.setAction("com.my.example.receiver.message");
                it.addCategory("android.intent.category.DEFAULT");
                PendingIntent pd =PendingIntent.getActivity(MainActivity.this,1,it,PendingIntent.FLAG_UPDATE_CURRENT);
                alarmManager.cancel(pd);

            }
        });
    }
}
