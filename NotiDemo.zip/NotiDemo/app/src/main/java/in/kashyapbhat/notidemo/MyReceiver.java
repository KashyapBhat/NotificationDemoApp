package in.kashyapbhat.notidemo;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        NotificationCompat.Builder myNot = new NotificationCompat.Builder(context);
        NotificationManagerCompat myMan =NotificationManagerCompat.from(context);
        myNot.setContentTitle("Yeah,Alarm is up!");
        myNot.setContentText("You need to wake up");
        myNot.setSmallIcon(R.mipmap.ic_launcher);

        Intent it = new Intent(context,Main2Activity.class);
        PendingIntent pd =PendingIntent.getActivity(context,1,it,PendingIntent.FLAG_UPDATE_CURRENT);
        myNot.setContentIntent(pd);
        myNot.setAutoCancel(true);
        myMan.notify(1,myNot.build());

    }
}
